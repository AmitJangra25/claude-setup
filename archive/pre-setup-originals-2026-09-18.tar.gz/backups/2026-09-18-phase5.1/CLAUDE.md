# Voice Flow

Personal macOS dictation app: a floating mic widget with a global hotkey,
speech-to-text, an AI polish pass, and auto-paste into whatever app is
focused. Also runs as a plain web app for local dev, but the desktop build
is the real product. Success = dictation that lands correctly formatted in
the focused app without the user touching the keyboard.

## Stack

React ^19.2.8, React Router ^8.3.0, Vite ^8.2.1, Tailwind CSS ^4.3.3.
Electron ^43.4.0 + electron-builder ^26.15.7 for the desktop shell/packaging.
Radix UI primitives, Motion, Lucide icons. Vitest ^4.1.10 + Testing Library + jsdom ^30.
TypeScript ^7.0.2. Node 22.23.2 on this machine (no version manager — see below).
All package updates are current as of 2026-08-16; `npm audit` is clean.

## Architecture map

- `electron/` — main process. `main.js` (windows: main + always-on-top
  widget), `preload.cjs` (contextBridge → `window.api`), `accountStore.js`
  (local account), `dataStore.js` (file-backed JSON), `clipboard.js`
  (auto-paste), `focusTarget.js` (frontmost-app tracking), `hotkey.js`
  (global hotkey), `localLlm.js`/`localWhisper.js` (offline mode — servers
  this app spawns and owns), `ollama.js` (offline polish via an Ollama
  service the user runs; no spawn, models picked by name not file path).
- `src/app/routes.tsx` — route table. Desktop build redirects `/` → `/app`
  (no marketing page inside the app).
- `src/app/pages/` — one file per route. **`settings/` has 13 tabs, grouped by
  Compose mode** since 21 Aug 2026: General · System · Models & Keys ungrouped, then
  **Dictate** (Shortcuts, Dictionary, Snippets, Styles, Agents, App Contexts, Vibe
  Coding), **Chat** (Threads, Attachments) and **Vault** (Vault). The grouping is a
  `group` field on the existing `tabs` array — display order is still array order and
  the rail derives its headings from it, so a fourth group is one field rather than a
  second list to keep in step. Models & Keys is deliberately *not* split: keys are
  global and the Ollama roles span all three modes. The keyboard shortcut lives in
  Shortcuts (not General) and "Show app in Dock" in System (not General) — both
  moved.
- `src/app/pages/Compose.tsx` + `pages/compose/` — the main screen, at `/app`.
  Beside the three modes: `SaveToVault.tsx` (the only control that puts something into
  `raw/`, and it asks which project before doing anything), `ThreadBar.tsx` (saved
  conversations, filtered by mode) and `VaultOffline.tsx` (what Vault renders instead
  of a composer when Ollama is missing — four states, no text box in any of them).
  **This was `Recorder.tsx`; that file no longer exists.** One surface, three
  modes: Dictate (`ComposeDictate.tsx`), Local and Vault (both
  `ComposeChat.tsx`, which differ only in who answers). The shell owns
  `useDictationPipeline` rather than each mode, so switching modes cannot tear
  down a running recording. Docs written before the rename say "Recorder" — they
  mean this page.
- **`src/app/lib/historyStats.ts` derives Insights, and its streak is calendar days,
  not milliseconds** (fixed 2 Sep 2026). `startOfDay` works in local time, so two
  consecutive midnights are 23 hours apart on a spring forward and 25 on the return — an
  exact `=== DAY_MS` comparison read both as a gap and restarted the run. Do not
  "simplify" the `Math.round(... / DAY_MS)` back. It cannot reproduce here (India has no
  DST), which is why `historyStats.test.ts` sets `process.env.TZ` per test.
- `src/app/lib/usageStats.ts` — lifetime counters behind the Insights screen
  (`usage.json`), deliberately separate from history: history is capped at 5000
  entries and pruned by the retention setting, so a streak or a lifetime word
  count derived from it silently resets. Counts only, never transcript text.
- `src/app/lib/appContext.ts` — per-app adaptation. `focusTarget.js` captures the
  frontmost app's bundle ID at record time; a matching profile injects an
  instruction into the polish prompt and decides whether stage 4 runs. Ships one
  profile (code editors) on purpose: an unmatched app must behave exactly as it
  did before contexts existed, and there is a test pinning that.
- **The vault modules in `electron/`** (Phase 2, Aug 2026). Eleven files, and the
  split is deliberate: the ones with no filesystem access hold the decisions worth
  being certain about, so they are settled by reading tests rather than by pointing
  a compiler at a real vault. `vaultStore.js` reads (containment, the wikilink
  resolver) · `vaultPaths.js` turns three slugs into a path and is the *only* place
  that decides one · `vaultPage.js` parses a page (frontmatter, links, H1) ·
  `vaultEdit.js` makes surgical edits · `vaultTemplate.js` owns the section names
  and order · `vaultTree.js` reads the declared hierarchy, which is the compiler's
  allowlist · `vaultPlan.js` (pure) is what would be written · `vaultApply.js` is
  the only thing that writes · `vaultCompile.js` is the cascade · `vaultDecide.js`
  is the model seam · `vaultLint.js` is the health check · `vaultRaw.js` (added
  21 Aug 2026) is the *other* write path — create-only, into `raw/` and nowhere else.
- **Tests 25–29 in `docs/manual-testing.md` have never been run.** 25–28 cover the
  21 Aug 2026 vault work — attachments, Save to vault, saved conversations, and Vault
  without Ollama. The automated suite is green on all of it; nothing has been through a
  real vault. **Test 29** was added 9 Sep 2026 for the silence refusal, and needs the
  microphone's input volume at zero — its more important half is that a real dictation
  still goes through. **Test 23 was re-run on 10 Sep 2026** on the two supported pairs
  and met Phase 2.75 item 6's bar — 14 clean of 14, shape honoured on every run that
  asked for one, word errors unmoved. **Gemini is the row still outstanding** (one run,
  and it fell back), and item 6 stays open until the whisper model measurement (item 10)
  has changed the transcribe leg under it.
- `src/app/lib/vaultSave.ts` / `attachments.ts` / `threadStore.ts` — the additive half
  of Phase 2. `vaultSave.ts` names a source and shapes it (`analysis-<topic>.md` for an
  answer, `note-<topic>.md` for a dictation) and the name is derived from the question
  so it is **stable** — that is what makes a second save a duplicate rather than a
  second copy. `attachments.ts` reads a dropped `File` in the renderer, which is why
  no read-a-path IPC exists. `threadStore.ts` is history's shape applied to
  conversations.
- **`src/app/lib/structureCues.ts` + `polishGuard.ts` are the two halves of a polish
  step you can rely on** (Phase 2.75, 9 Sep 2026), and the split is the design.
  **`structureCues.ts` decides the SHAPE, in code, before the model reads anything** —
  the prompt then *states* the answer instead of asking for it. **`polishGuard.ts`
  reads what came back**, as a pure function of (text sent, text returned, plan), so it
  is settled by reading tests rather than by running a model. Both are import-clean —
  no settings, no storage, no DOM — because `scripts/doctor-polish.js` imports them
  directly. The finding that produced them: fourteen runs of the §10.5 script, the same
  words each time, came back as **five different shapes**, and all fourteen were
  recorded as successes. Two of the five were serious — one duplicated a paragraph and
  moved a third of the content, one invented *"OpenAI is the second fastest"* — and
  both were **technically obedient**, because every rule in the prompt forbade changing
  the speaker's words and none forbade adding new ones.
- `src/app/lib/textPipeline.ts` — the 5-stage dictation pipeline:
  dictionaryCorrect → spokenPunctuation → polish LLM → vibeCodeProcessor →
  snippets. Order is load-bearing (see Working rules).
- `src/app/lib/voiceflowSettings.ts`, `dataStore.ts` — settings/data,
  file-backed in Electron, localStorage fallback when `window.api` is absent.
- `src/app/hooks/useDictationPipeline.ts` — shared record→transcribe→polish→
  paste state machine used by both the Compose page and the floating widget.
  Takes an `autoPaste` option — Compose passes `false` (it renders the transcript
  in the page), the widget leaves it on. A new surface built on this hook has to
  opt in rather than inherit widget behaviour by accident.
- **`src/app/hooks/useCopyToClipboard.ts` is the only place that copies**, and a
  sixth hand-rolled `useState` + `setTimeout(…, 2000)` is the thing not to write
  (added 8 Sep 2026, replacing five). The three faults it removes were in **all
  five** copies, which is the argument: `writeText`'s promise was dropped, so a
  rejected write still rendered "Copied!"; `navigator.clipboard` is absent outside
  a secure context and only one guarded for it; and the timer outlived the
  component, holding a `setState` on something unmounted. Pass a `key` for a list
  (`isCopied(row.id)`) and nothing for a single control. Copying a second thing
  clears the first confirmation **on purpose** — the clipboard holds one thing.
  Note it is `async`, so a test asserting the confirmation needs `findByText`
  rather than `getByText`.
- **A delete that cannot be undone asks first, through `ConfirmDialog`.** History's
  row delete did not until 8 Sep 2026, while `TranscriptionDetail` — the detail
  view of the same entry, calling the same `deleteHistoryEntry` — always had, in a
  dialog reading *"This action cannot be undone."* Two screens disagreeing about
  one action is the shape to watch for. **Settings → Snippets, Styles and Agents
  followed the same day, so the rule is now simply: a delete asks.** No screen is
  left deciding for itself which kind of delete it has. **`ThreadBar.tsx` and
  Settings → Dictionary were the last two holdouts, closed the same day** — the
  first deleted a saved conversation on the first click while Settings → Threads
  guarded *delete all* over the same `deleteThread`, and the second was the one
  Dictate tab missed when Snippets/Styles/Agents got dialogs. Dictionary's delete
  still acts on the entry's **real index**, not its text: `visibleEntries` carries
  that index through the search filter on purpose, and keying the dialog on the
  word would delete both of two entries sharing it.

  **`Button` has a `size="icon"` (40px square, no padding) and a trash icon in a
  list row uses it.** Added 8 Sep 2026 because there was no square size, so six
  screens each hand-wrote a raw `<button>` for that one control — 28px, 40px and
  44px targets, icons at `w-3.5`/`w-4`/`w-5`, and `SettingsAgents` putting the
  hover colour on the *icon* so it only lit up over the 16px glyph. A new
  icon-only control has a size to reach for now; a seventh hand-rolled one is the
  thing not to write.

  **Styles is the exception worth knowing, and it is about wording, not whether it
  asks.** Four of its five styles are built-ins, and the trash icon on one removes
  your *override* — `deleteStyleProfile` drops the stored entry and
  `getVisibleStyleProfiles()` puts the built-in back, so the style stays on the
  page. `pendingDeleteIsBuiltIn` therefore switches the dialog to "Reset style" /
  "Reset", and only a custom profile gets "Delete" and the words "cannot be
  undone". A dialog that promises permanence over something that plainly comes
  back is how a user learns to stop reading dialogs. `settingsPages.test.tsx`
  pins both wordings, and its pre-existing delete test deletes **Formal** — a
  built-in — so it clicks Reset.

## Working rules

- **Format is computed; register is inferred. Do not give the model the format
  decision back.** This is the rule the whole of Phase 2.75 rests on. `auto-detect`
  used to be one sentence — *"Infer an appropriate tone from the content itself."* —
  silent about format, so the model chose the shape and chose differently every run.
  It now asks for register per sentence (contractions, written-out forms, how complete
  a sentence is) and says outright that this is *"a choice about spelling out words
  only"*. That bound is load-bearing: once "never swap a word for a smarter one" holds,
  register is all a model can vary without losing or moving something — which is why
  mixed-register auto is compatible with reliability rather than opposed to it.
- **A bulleted list means a list the speaker rattled off.** Three or more *adjacent*
  short marked sentences with at least one ordinal, or an explicit spoken request.
  Adjacency is what matters: the §10.5 script names three steps out loud and is
  **prose**, because each step carries four or five sentences of detail, and bulleting
  only the step sentences is what stranded that detail in the worst measured run.
  `structureCues.test.ts` pins the script as **`sections`**, and still asserts it is
  never `list` — that is the shape that strands the detail, and going green on it
  means the app has started reformatting text nobody asked it to. The old prompt rule
  cued on ordinals **and** sequence words ("then", "after that"), and read aloud an
  ordinary dictation contains both, so the rule described two possible lists and left
  the model to pick. `npm run doctor:polish` says 117 of 118 real dictations license no
  list at all.
- **There are three shapes, and `sections` is the one for topics that carry detail**
  (added 9 Sep 2026). `prose` and `list` were the only two, so a dictation that
  numbered its topics out loud and then talked around each one had no correct
  answer: `list` bulleted the topic sentences and **stranded their detail**, and
  `prose` threw away an organisation the speaker had stated aloud. `sections`
  numbers the topics and keeps everything said under one as running prose beneath
  it, so no sentence moves. The §10.5 script is the reference case. Measured over
  135 real dictations: 42 classify as `sections` and **all 42 are repeats of that
  script** — no ordinary dictation changed shape, which is the check to re-run
  (`npm run doctor:polish -- --plans`) before widening any cue. Two things not to
  "simplify": `MAX_SECTION_TOPIC_WORDS` (16) is deliberately wider than
  `MAX_ITEM_WORDS` (12) because a bullet must be short while a section topic is a
  whole sentence introducing a paragraph; and `leadSpans` records the ordinal
  lead-in ("The first step is ") so `dropped-content` does not fire on the model
  correctly removing what the number already says — the same licence
  `requestSpan` gives the spoken request for a list.
- **The shape is computed from the transcript, so shape stability is bounded by
  transcription accuracy** (measured 10 Sep 2026). Two of eleven Test 23 runs planned
  `prose` rather than `sections` because whisper mangled *"The third step is the widget
  itself"* into *"Groq itself which still feels heavy"* — the third ordinal went with the
  words, leaving two marked topics where `MIN_LIST_ITEMS` needs three. The cue rule was
  right about the text it was given. So a run that comes back a different shape is not
  automatically a polish bug, and this class is invisible to `polishGuard.ts` by
  construction: words the transcriber lost are absent from the text it compares against.
- **A guard violation costs the style pass, never the words.** One retry, told what to
  do *instead* (`correctionsFor`) rather than what it did wrong; a second violation and
  nothing the model returned is used — `applyFallbackCleanup` runs on the text that
  went in. One retry rather than a loop on purpose: a model that ignores the rule
  restated in front of it will not find it on a third pass, and this is the dictation
  hot path.
- **An agent or a list-shaped style licenses structure, and both the prompt and the
  guard must agree about that through one function.** `structureLicensedByChoice` is
  that function; `activeStructureLicensed` in `textPipeline.ts` is the live-settings
  wrapper. Two copies of this decision would let a model be told bullets are fine and
  then be retried for producing them. Four dictations in this history are Bug Report
  agent output — "Summary / Steps to Reproduce / Expected Result" — which is the agent
  doing exactly its job.
- **A guard check is a violation only if it is provable from the text.** Four kinds were
  written as violations and the replay demoted one: `dropped-content` looked like the
  most important check in the file and is the least usable, because on a stuttery
  dictation the model correctly removes 40% of the content words and that is
  `backtrackCorrection` working, indistinguishable from having lost them. Its one
  genuine catch across 118 dictations was already caught by `unlicensed-structure`.
  `novel-content` fires on 64% of the history, which measures the check rather than the
  models. **Promoting a warning is a one-line change and a measurement, not a rewrite** —
  do the measurement. Note also what the guard can never see: words lost by the
  *transcriber* are missing from the transcript it compares against, so that class of
  failure is invisible here by construction and belongs to `npm run benchmark`.

  **The replay has now demoted a second one, and it is the same rule applied to
  `sections`** (8 Sep→9 Sep 2026). `wrong-item-count` on a `sections` plan was a
  violation on the reasoning that a missing numbered line means a topic's detail got
  folded into the one above it. Measured through the real prompt and real guard, three
  runs each, that was backwards: `qwen3.5:4b` returned **zero** numbered lines and 168
  words of 165 — nothing lost — `llama3.2` returned one stray `1.` and lost nothing, and
  `granite4.1:8b` was the only model that complied and it **dropped the opening
  sentence**. So the two answers it refused kept every word and the one it passed did
  not. `qwen3.5:4b` had organised the text, inline in one paragraph, which is what the
  prompt's own *"as running prose on the same line"* invites and what a line-anchored
  `BULLET_LINE` cannot see; restating the rule harder made it *less* compliant.
  Producing `sections` is an 8B-and-up capability and the Ollama tier is where the small
  models live. A missing number does not prove a lost word, so it warns. **The demotion
  took `doctor:polish` from 49 violations of 135 (36%) to 18 (13%) while reclassifying
  31 findings and hiding none** — every other kind's total is unchanged, which is the
  check to repeat on any future promotion. `wrong-item-count` on a `list` plan is still
  a violation: N short items rattled off and a different number returned is provable.
  Note `correctionsFor` takes the **plan** for exactly this reason — the same kind means
  opposite things on the two shapes, and it was telling a `sections` retry to *"produce
  a bullet for each listed item"*, which is the stranding that shape exists to prevent.
- Keep the pipeline order in `textPipeline.ts` intact: dictionary +
  punctuation must run pre-LLM, vibe-code + snippets post-LLM.
- Vibe Coding's global switch in Settings is only the **fallback** for apps with
  no App Context. A matching context overrides it in both directions, so don't
  reason about stage 4 from `getVibeCodeSettings().enabled` alone.
- New Settings tabs get registered in **both** `routes.tsx` and the `tabs`
  array in `pages/Settings.tsx` — they're two separate lists that must agree.
- **A data category is a whitelist, in *three* places that must agree** (two since
  19 Aug 2026, three since 21 Aug 2026). `CATEGORIES` in `electron/dataStore.js` is the
  set of names that may become a file in the data folder, and `write-data` in `main.js`
  checks the renderer's category against it before writing — the name is interpolated
  into a path, so an unchecked one escapes the folder. `preload.cjs` holds its own copy
  because it is CommonJS and cannot import the module. The third is
  `CATEGORIES` in `src/app/lib/dataStore.ts`, a literal array beside the `Category`
  union, because `clearAllCategories()` has to *iterate* the categories and a
  TypeScript union does not exist at runtime — so "delete my data" is exactly as
  complete as that array is. `dataStore.test.js` reads both other files as text and
  asserts all three match, so adding a tenth category means editing three. Same shape
  as the tabs/routes pair above. There are nine today; `threads` is the newest.
- **The dev product name lives twice, and `scripts/` cannot be imported from
  `electron/`.** `main.js` calls `app.setName('Voice Flow (dev)')` and
  `scripts/appFootprint.js` exports the same string as `DEV_APP_NAME`, which is
  what `uninstall:app` deletes. They cannot be shared: electron-builder's `files`
  array packages `electron/` but not `scripts/`, so a cross-import breaks the
  built app. Change them together or an uninstall silently leaves the dev profile.
- **`ollama.js` talks to Ollama's native `/api/chat`, and must keep sending
  `num_ctx` and `think`** (moved off `/v1/chat/completions` 20 Aug 2026). Both
  things it gained fail *silently* if dropped. Ollama gives a request that names
  no context window a flat default (16384 here) and, when the prompt exceeds it,
  keeps roughly the last half **from the front** — HTTP 200, no flag. Measured:
  a 25,059-token prompt evaluated 8,194 tokens and answered as if the system
  message were absent, which for vault chat is the instruction saying the pages
  are passive data and never commands. So `contextWindowFor()` sizes the window
  per request and **throws** rather than let a prompt be cut; that error is the
  feature. Two things not to "simplify": the size is bucketed to powers of two
  because changing `num_ctx` reloads the model (767ms for a one-token change vs
  117ms for none), and the char/3 token estimate over-estimates on purpose —
  under-estimating costs the system prompt. `think: false` goes on every request
  (9.9s → 2.1s on qwen3.5:4b for a byte-identical answer); it is safe on models
  with no thinking capability, and a model that refuses it is remembered and
  retried without it, like `sendDroppingRefusedParams`. Do not restore the
  picker's old "thinks first — slow for dictation polish" warning: it is now
  advice to work around something the app handles.
- **The renderer must never navigate anywhere, and `electron/navigationGuard.js`
  is where that is decided** (added 20 Aug 2026). Default Electron behaviour
  sends the clicked page into *the app window itself*, which has no chrome and no
  back button, and takes `window.api` with it. The guard is registered on
  `app.on('web-contents-created')` at module scope — not per window, and not
  inside `whenReady()`'s try/catch — so a third window cannot miss it. Two traps:
  `isInternalUrl` compares protocol **and host**, never `origin`, because in the
  main process `app://voiceflow`, `mailto:`, `file:` and `javascript:` all have
  origin `"null"` and an origin check waves all of them through; and
  `isExternallyOpenable` is an allowlist (`http:`/`https:` only) because
  `shell.openExternal` launches whatever the OS registered for a scheme. Adding
  `obsidian:` for wikilinks is a deliberate edit there.
- Anything that asks Ollama a question reads **`getOllamaModelFor(role)`**, never
  `getOllamaModel()`. There are three roles — `polish`, `chat`, `vault` — because
  they want opposite models: polish is in the dictation hot path and wants the
  smallest thing that works, vault sends eight whole notes and wants the longest
  context. **`polish` is `qwen3.5:4b` and `vault` is `qwen3.5:9b`, both chosen by
  measurement** — polish on 10 Sep 2026 over all 134 dictations
  (`doctor:polish --rerun`), and the surprise there is that **the 9B of the same family
  buys nothing for polish**: same words kept (97.7% against 97.5%), shape honoured
  slightly less often, 2.1× the latency. So "bigger for quality, smaller for speed" is
  not the trade on this task, and the two fastest candidates were the ones disqualified
  — `granite4.1:8b` honours the requested shape on 133 of 134 dictations *by discarding
  content* (76 `dropped-content` findings), and `llama3.2:latest` answered the §10.5
  script with three numbered lines and 22 words of 163, three times. Do not re-derive
  this from model size; re-run the command. Each falls back to the shared `getOllamaModel()` when unset, so the
  old single-model behaviour is still the default; calling `getOllamaModel()`
  directly is what silently ignores an override the user has set.
- **The Ollama model pickers live in their own "Ollama models" section, not inside
  the Polish engine radio** (fixed 2 Sep 2026, `SettingsModels.tsx`). Two of the
  three roles have nothing to do with polish: `ComposeChat.tsx` and `VaultOffline.tsx`
  call `getOllamaModelFor(role)` with no reference to `polishEngine`, so they use
  Ollama whatever polish is set to. While the controls sat in the
  `polishEngine === 'ollama'` branch, **selecting Cloud polish hid the Vault model
  picker while Vault kept querying Ollama** — the setting was unreachable from the UI
  and the feature depending on it went on running against whatever it was last left
  with. The probe was gated identically, so even a rendered picker had an empty list.
  This is how `ollamaModels.vault` came to be silently wrong twice; the standing note
  about hand edits losing to the app explains how it got *lost*, this explains why it
  could not be *put back*. Two smaller things that came with it: the install
  walkthrough now renders only while `ollamaProbe !== 'running'` (it is a permanent
  three-step guide otherwise, in a section that is always on screen), and the
  "pick a model" warning names Chat and Vault rather than polish alone. `settingsPages.test.tsx`
  asserts all three rows render for **every** polish engine — verified to fail against
  the pre-fix file, not just to pass against this one.
- **Every JSON file this app writes goes through `writeJsonAtomic`** in
  `electron/atomicWrite.js` (temp file + rename). Added 19 Aug 2026 — do not go back
  to a bare `fs.writeFileSync` for a store. The failure it removes was silent and
  total: every reader here is `try { JSON.parse(read()) } catch { return null }`, so a
  process killed mid-write left a truncated file that parsed as "no data" and the app
  started **empty**, with no error. The old comments called the plain write deliberate
  and that was fair at a 50-entry history cap; it stopped being fair at 5000, since
  `history.json` is rewritten whole after every dictation (86KB at 62 entries, ~7MB at
  the ceiling). Covers `dataStore.js`, `accountStore.js` and `main.js`'s
  window-bounds writer. `preload.cjs` no longer writes at all. **Rename, not fsync**,
  on purpose — the property wanted is old-or-new, never torn; durability against power
  loss would cost a disk flush per dictation to protect only the newest save.
  `atomicWrite.test.js` pins the mechanism by spying on `fs`, because a torn write
  cannot be produced in-process — reverting to a direct write turns it red.
- **Every `fetch` to a local server needs its own budget, and a deadline checked
  after an `await` is not one** (localLlm 2 Sep 2026). `electron/localLlm.js` had no
  `AbortSignal` at all: a wedged `llama-server` hung the polish step with no error and
  no ceiling. There is no network stack to time a 127.0.0.1 request out on your behalf,
  which is exactly why it stayed invisible. Two budgets now, and the second is the
  instructive one — `waitForHealth` *looked* bounded by `HEALTH_TIMEOUT_MS`, but it
  reads the deadline **after** the poll's await, so one `/health` fetch that connected
  and went quiet meant the loop never came back round and 20s never fired. Generation
  is 120s, the same number `ollama.js` uses, deliberately one number rather than two for
  the same job; the 2.5s speed benchmark is the *typical* dictation and a ceiling set
  from the typical case aborts the tail. The budget converts "hangs silently" into
  "fails and names the step" — `useDictationPipeline` already falls back to
  `applyFallbackCleanup`, so a timeout costs the style polish, never the words.

  **`electron/localWhisper.js` got the same treatment on 9 Sep 2026, and one number is
  deliberately different.** It had neither budget and carried the identical
  read-the-deadline-after-the-await defect, so a wedged `whisper-server` left the app on
  "Transcribing…" forever — and it is the binary Phase 3 bundles for every user. The
  health probe is the same 2s. **The decode budget scales with the audio**, because
  polish output is bounded by the transcript while decode time is bounded by the
  *recording*: at 4x realtime, well inside what this machine measures with
  `--beam-size 5`, a ten-minute dictation is 150s of real work, so the flat 120s would
  abort the tail rather than catch a hang. `transcribeTimeoutMs()` reads duration off
  the byte count — `audioResample.ts` hands it 16kHz mono PCM16, exactly 32,000 bytes a
  second — with a 60s floor, 2s per second of audio and a 10-minute backstop. Same
  shape as `transcriptionTimeoutMs()` on the cloud path. Unlike a polish timeout this
  one has **no fallback**: there is no transcript to keep, so the error has to name the
  step and the way out.
- **A loud peak is not evidence of intelligible speech, and a Bluetooth mic is how you
  find that out** (11 Sep 2026). A Test 23 session produced four unusable transcripts in a
  row — the Dictionary prompt returned verbatim, one sentence repeated nineteen times,
  8 words from 74 seconds — across **OpenAI, Groq and local whisper**, which is what
  eventually pointed away from the app. The default input was AirPods-class earbuds that
  were also the default *output*, so macOS had them in the hands-free call codec at
  **16 kHz**: `audioLevel.ts` measured peaks of 0.56-1.0 and passed every one, because the
  signal was loud and the codec had destroyed the speech inside it. Three things follow.
  **`system_profiler SPAudioDataType` is the fastest diagnosis** — it prints
  `Default Input Device: Yes` and the sample rate, and a Bluetooth input at 16 kHz beside a
  44.1 kHz output is the tell. **The app's own error message was right and was talked past:**
  it said to check the microphone, and the loud peak was used to argue against it. And
  **the cloud path sends the raw MediaRecorder blob** (`transcribeViaWhisperApi`), not
  `encodeWav16kMono`, so a bad recording reaches every provider identically — which is why
  three providers failing the same way means the audio, never the provider.
- **Silence is refused before it is sent, and an echo of the Dictionary prompt is
  refused when it comes back** (added 9 Sep 2026, `src/app/lib/audioLevel.ts` and
  `isPromptEcho` in `transcription.ts`). Two ~75s dictations came back as text nobody
  said — one *"Good evening, ladies and gentlemen…"*, the other `buildDictionaryPrompt()`
  **verbatim** — and both were polished and pasted as the user's words. That is Whisper's
  no-usable-speech behaviour, not a bug in it: the `prompt` parameter is prior *context*,
  so continuing it is an ordinary thing to do with audio it cannot use. The app could not
  say afterwards whether the microphone had produced anything, because it kept neither
  the audio nor the loudness.

  Three things here are load-bearing. **The peak is sampled on every animation frame,
  before the meter's own 60ms throttle** — the bars are throttled because sixty state
  updates a second is wasted rendering, and the peak is not, because a skipped frame is a
  chance to miss the loudest instant and that instant decides whether the audio is sent.
  **`unmeasured` is a real verdict and it proceeds**: there is no `AudioContext` in the
  browser build or under jsdom, and an OS that thinks the widget is hidden throttles the
  frame, so `levelVerdict` says `unmeasured` below four frames a second of coverage.
  Absence of a measurement is not evidence of silence, and refusing on it would lose real
  words — the same failure from the other side, and a worse one. **The echo check is
  equality after normalising, never similarity**, with whole repeats folded together for
  a decode loop: a dictation *about* the terms in your own dictionary is a real thing to
  say, and the guard's rule applies here too — act only on what is provable from the
  text. `SILENCE_PEAK` (0.02, -34 dBFS) is arithmetic rather than measurement, which is
  why `audioPeak` is stored on **every** entry: that is what makes the threshold
  arguable later, the same relationship `doctor:polish` has to `MAX_DROPPED_WORDS`.
- Desktop persistence goes through `dataStore.js`, not raw `localStorage`.
  `localStorage` is the browser-only fallback path — don't use it as the
  primary store for anything meant to survive in the desktop build. **Vibe
  Coding's switches were the last *setting* outside it** (moved 20 Aug 2026) and
  now live in `voiceflowSettings.ts` as `VibeCodeSettings` beside `AiProcessing`.
  That is also where a *new* settings shape goes — a second module writing
  `settings.json` needs its own read-merge-write, which is two write paths to one
  file. `vibeCodeProcessor.ts` imports `getVibeCodeSettings` from there.
  **One deliberate exception remains: the theme.** `ThemeContext.tsx` keeps
  `voiceflow_theme` in `localStorage` on purpose — the widget is a separate
  renderer, and it follows a theme change by listening for the `storage` event,
  which only fires for `localStorage`. Don't "finish the job" by moving it without
  replacing that sync, or switching to Dark leaves a near-white capsule on screen
  until restart.
- **The vault has a fourth level above the project — the *space* — and it is the
  one destination field a model never chooses** (added 8 Sep 2026).
  `wiki/Work/project-v-thru/app-customer/mod-login.md`,
  `raw/Personal/project-diary/note.md`. `spaceOfSource()` reads it off the
  source's own path and `destinations(tree, space)` scopes the catalogue to it,
  so the model is shown one space's modules and never told another exists. The
  reason it is not a model's call: a wrong slug writes a page in the wrong
  folder, a wrong space writes a personal note into a client's project. **Save to
  vault asks for it** — and only when more than one space exists, like the
  project. Three things not to "simplify": the space is **required** by
  `pathForPage` rather than defaulted (a silent default is the bug below); it is
  validated by its own `SPACE` pattern because `Work` is capitalised and fails
  `SLUG`; and `readSpaces()` reads the folders rather than holding a list, so a
  space is created by making one in Finder and nothing else.

  **This landed because of a real mis-filing, and the shape is worth remembering.**
  The vault was reorganised by hand into `Work`/`Personal`; `readTree` still read
  `wiki/projects/`, found it **empty**, and passed the model *"the wiki has no
  modules yet — everything is new"*. At that point the only concrete JSON in the
  whole prompt was the `Example:` line, and the model answered with the example's
  own slugs — filing a real Work CSV into an invented `demo/shop`. Two fixes, not
  one: the tree reads every space, **and** the example's slugs are now
  `example-project`/`example-app` with a rule forbidding their reuse. An
  illustrative example in a prompt is an answer waiting for an empty question.

- **Nothing writes to the vault except an approved plan, and four separate things
  make that safe** (Phase 2, Aug 2026). Do not weaken any of them to make a write
  simpler. **1. The model never emits a path.** It returns three slugs, checked
  against the declared tree *and* `[a-z0-9-]` before `vaultPaths.js` builds a path —
  a source document saying "file this under `../../.obsidian`" produces a rejected
  slug, not a traversal. **2. Only `wiki/` and `raw/` are writable**, as an
  allowlist rather than a denylist, because the vault root holds files this app has
  never heard of. **3. Every write is atomic** (`writeTextAtomic`). **4. Apply
  re-hashes every target and aborts if one moved** — Obsidian is open on those
  files while the preview is on screen.
- **`assertInsideVault` fell back to a lexical resolve when the target did not
  exist, which is *always* true of a file being created.** Fixed 21 Aug 2026 and
  renamed `resolveInsideVault`. Lexical resolution does not follow symlinks, so a
  symlinked directory inside `wiki/` passed the prefix test and the write landed
  outside the vault — verified by running the old function and finding a real file
  in the target. It now canonicalises the **deepest existing ancestor** and rejoins
  the tail. Note the test trap this exposed: `os.tmpdir()` is `/var/folders/…` on
  macOS and `/var` is a symlink to `/private/var`, so a test root that is not
  `realpath`ed makes every containment assertion pass for the wrong reason.
- **The compiler builds one plan per source and they must share an `overlay`.**
  Two sources filed into one application otherwise each build their edit from the
  same on-disk text, so neither contains the other's and merging silently drops
  one. Invisible in a single-source run, which is every run until it is not.
  `mergeCompilePlans` is shared by the UI and the CLI so they cannot disagree, and
  it re-reads `before` from **disk** — hashing text that was never on disk makes
  every multi-source compile abort as stale.
- **`removedLines` decides its flag on words and its list on lines**, and both
  halves were learned by running against the real vault. Word-level for *whether*
  anything is going: adding `webapp` to `apps: [customer, pos]` rewrites that line
  without losing anything, and a line-level check fired the warning on the safest
  edit the compiler makes. Line-level for *what to show*: a word is not something a
  reader can look at, and a line still present in `after` is plainly not going
  away. A warning nobody trusts is worse than no warning.
- **A settings write from a running app clobbers a file edit.** `readSettingsFile`
  reads an in-memory cache seeded by `preload.cjs` **at launch**, and
  `writeSettingsFile` writes `{...cache, ...patch}`. So editing
  `data/settings.json` by hand while the app is open works until the user changes
  any setting in the UI, at which point the launch-time snapshot wins. It happened
  on 21 Aug 2026 — a hand-set `ollamaModels.vault` was erased by a UI change to the
  shared model minutes later. Change settings in the app, or quit it first.
- No telemetry/analytics collection — this is a stated security property.
- When a setting moves between tabs (it has happened — see gotchas), update
  README.md/docs/installation.md in the same change, not later.
- **`localStorage.clear()` is not "delete my data", and was the whole of Delete
  Account until 21 Aug 2026.** It cleared a store the desktop build does not use and
  left `history.json` and `api-keys.json` where they were, while the comment beside it
  claimed it wiped everything. `clearAllCategories()` in `src/app/lib/dataStore.ts` is
  the real thing; Account calls both, because the browser build genuinely does use
  localStorage. Found while adding threads to the export — a delete that misses one
  category misses all of them.
- **`raw/` is also written by a person in Finder, and the compiler's read path had no
  format gate until 2 Sep 2026.** `READABLE_SOURCE_EXTENSIONS` in `vaultTree.js` is that
  gate, kept equal to `TEXT_EXTENSIONS` in `src/app/lib/attachments.ts` by a test that
  reads the other file as text — they cannot import each other (renderer vs main), the
  same split that makes `preload.cjs` keep its own `CATEGORIES`. The reason it matters:
  `attachments.ts` enforces the formats on the *write* path, in the renderer, which says
  nothing about what `readSources` will *find*. The first real compile run fed an `.xlsx`
  to the model as utf-8 — a zip, whose first legible bytes are `xl/drawings/drawing1.xml`
  — and the model proposed a **new module page called `drawing`**. `unreadable` is
  returned and printed rather than silently skipped: a file the compiler ignores without
  a word is indistinguishable from a compiler that does not work, and someone put it
  there on purpose.
- **Three things learned by running the compiler for real** (2 Sep 2026), none visible to
  a green suite. **A timeout is not a connection failure:** `AbortSignal.timeout` rejects
  into the same `catch` as a refused connection in `ollama.js`, and the connection wording
  won by being first — a slow model told the user to restart a service that was answering
  instantly. They have opposite fixes, so keep them apart. **A top-level `await` rejection
  does not reach `process.on('unhandledRejection')`** — Node reports it directly, so
  `compile-vault.js` wraps its model loop in a real try/catch instead; the handler that
  looked like it worked never fired. **A list arrives in three shapes, not two:** an array,
  newline-separated, and — `llama3.2`'s — one string carrying its own `1. … 2. …` with no
  newlines at all, which the newline split turned into a single bullet. `splitInlineList`
  in `vaultDecide.js` is deliberately narrow: numbering must start at `1.` and carry a
  second marker, and a bullet asterisk must have no digit either side, or `2 * 4 vCPU`
  splits in half.
- **`raw/` is written by `vaultRaw.js`, and it is create-only** (added 21 Aug 2026).
  This is the second write channel into the vault and it has no diff to approve, which
  is fine for a reason rather than by omission: there is no existing text to lose. Four
  things hold that up, and none is optional. The destination is a validated slug through
  `pathForRawFile`; the filename goes through `safeRawFileName`, which discards a
  directory component rather than rejecting it (`../../etc/passwd` becomes `passwd`);
  an existing path is **never** overwritten (`nextFreeName` suffixes `-2`); and the
  write goes through `applyPlan`, so containment, the `wiki/`+`raw/` allowlist and the
  atomic write are the same code the compiler uses. **Dedup is by content, not by
  name** — the same attachment answered three questions is three button presses, and a
  name check would have put three copies in `raw/` for the compiler to file three
  times.
- **An attachment is read in the renderer, and that is a security decision, not a
  convenience.** `attachments.ts` takes a `File` from a drop or the picker and calls
  `file.text()`. The alternative was an IPC that turns a path into file contents, which
  is one prompt-injected instruction away from being a read-anything-the-model-names
  IPC — in an app whose whole vault design keeps path decisions in the main process.
  Two consequences worth knowing: **there is no path to store**, so a saved thread keeps
  the document's *text* (the roadmap's "text plus the path" is stronger than planned),
  and the format allowlist is enforced in the renderer where the byte ceiling also is.
  `MAX_ATTACHMENT_BYTES` (128 KB) is deliberately far below `MAX_RAW_BYTES` (1 MB): an
  attachment is re-sent with every follow-up question in the thread, alongside up to
  eight whole wiki pages, and `ollama.js` **throws** rather than let a prompt be cut.
- **A file dropped anywhere in the window navigates it to `file://` and blanks the
  app**, and the prevention is the `dragover`/`drop` `preventDefault` pair in
  `src/main.tsx` — global, before React mounts, and it runs for the widget renderer
  too. `navigationGuard.js` refuses that navigation in the main process as well; this
  is the layer that stops the drag being treated as a navigation at all, which is also
  what stops the cursor offering to open the file. Do not move it into the chat's drop
  zone: the bug is entirely about the 95% of the window that is *not* a drop zone.
- **A thread is written whole, when the conversation settles.** `saveThread` takes the
  turns array, not one turn, and `ComposeChat` calls it from an effect guarded on
  `pending` rather than from the end of `send`. Two reasons: there are three ways a
  turn finishes (an answer, a refusal, a thrown error) and a save in each branch is
  three places to forget one; and a thread whose last answer is the word "Thinking" is
  a conversation the user cannot tell was interrupted. Threads are in `dataExport.ts`
  and in `clearAllCategories()` because a saved vault answer holds text copied out of
  the user's notes — an export or a delete that skipped them would be quietly
  incomplete about the most surprising thing in the folder.
- **An empty page selection from stage 1 is answered, not refused** (fixed 8 Sep
  2026). `SELECT_PROMPT` tells the model *"If nothing is relevant, reply []"*, so
  "hi" produces `[]` by obeying it — and `askVault` used to throw *"Could not work
  out which of your notes to read for that."* Two meanings were being conflated: a
  message that was never about the notes, and a vault question whose pages could
  not be chosen. `answerWithoutPages` serves both under `NO_PAGES_PROMPT`, which
  states outright that none of the user's notes were supplied — that sentence is
  what keeps this from becoming general-purpose chat wearing Vault's hat, and the
  reason it must not be softened. The `VaultAnswer` comes back with every field
  empty so the card reads "no vault pages read" and the deeper-read offer stays
  hidden. **A named page that does not exist is still a hard error** — that is a
  real vault defect, unlike a greeting.

- **The deeper vault read reuses its page set and adds an answer rather than replacing
  one.** `askVault({ pages, withSources: true })` skips stage 1 on purpose — a second
  selection call could name a different list, which would make the two answers
  incomparable — and the UI appends a turn, because the shallow answer is the evidence
  about what the wiki page alone supports. `readPageSources` dedups a document cited by
  two pages, since the same spec twice is how a model is made to contradict itself
  about which of two identical passages it meant. `readVaultPages` returns a
  `sourceCount` per page so the offer can be hidden when there is nothing to open —
  existence of the cited file is deliberately *not* checked there, because a
  `sources:` entry naming a document that is not in the vault is a vault defect and
  `doctor:vault` already reports it as `missing-source` (`mod-login` has two today).
- `docs/code-conventions.md` holds the code/UI conventions (comments record *why*;
  container queries inside the shell; colour from tokens; no control that
  renders without acting; every module reachable). It is tracked in git and
  deliberately does **not** repeat this file — don't copy rules between them,
  or one starts lying the first time the other changes.
- **Nine docs were renamed on 17 Aug 2026** and `docs/README.md` is now the
  index. A new doc gets a row there in the same change, and a name that says what
  it *is* — spelled out, kebab-case, no abbreviations. Old name → new:
  `testing` → `manual-testing`, `test-coverage-plan` → `unit-test-coverage`,
  `next` → `backlog`, `plan` → `roadmap`, `install` → `installation`,
  `guidelines` → `code-conventions`, `product-spec` → `product-specification`,
  `package-updates` → `package-upgrade-log`, `compose-ui-prompt` →
  `compose-ui-mockups`. `local-models` was already right.
- **`docs/archive/` holds finished documents**, and being there *is* the status
  marker — nothing in it is maintained against the code, so when one contradicts
  the app the app is right. Six documents, and they are two different kinds:
  **superseded descriptions of the app** (`product-specification.md`,
  `package-upgrade-log.md`, `compose-ui-mockups.md`) and **the dated history the
  live documents were rewritten out of** (`roadmap-old.md`, `backlog-old.md`,
  `manual-testing-pass-records.md`) — the second kind is cited *from* the live
  docs on purpose, so a decision's reasoning survives without the plan carrying
  it. Archiving means three
  things in one change or it defeats itself: fix the links *inside* it (it moved a
  level down, so `../CLAUDE.md` → `../../CLAUDE.md`), fix the links *to* it, and
  move its row in `docs/README.md`.
- **There is now exactly one by-hand test guide, `docs/manual-testing.md`, and it
  is pinned by a test.** The two guides were consolidated on 19 Aug 2026: the
  plain-language wording survived at the reference's filename, and
  `manual-testing-simple.md` is **deleted** — do not recreate it, and do not add a
  second register of this document. The prediction that killed it is worth knowing:
  two registers do not drift into contradicting each other, one of them just goes
  quiet, which is what happened when the 18 Aug fixes landed in only one. Its two
  completed pass records are at `docs/archive/manual-testing-pass-records.md`.

  `benchmark.test.ts` reads the file by path and asserts the 15-line script in
  **Test 23** matches `BENCHMARK_SCRIPT` in `src/app/lib/benchmark.ts`. Renaming the
  file, renaming the `## Test 23: Speed check` / `### The fixed input` /
  `### Procedure` headings, or editing the script in one place only, all fail the
  suite — which is the point, but know it before you edit that section. The two
  `###` anchors exist **for the test**, not for the reader; the file also carries a
  status blockquote and a measured-results table inside that section, and the test
  slices between those anchors precisely so it does not swallow them.

  **Tests 1–24 all passed on 19 Aug 2026**, and Test 23 produced the first real speed
  benchmark — see `docs/archive/backlog-old.md` §3, which had gated streaming STT on that table
  existing and is now answered: the time is in polish, not transcribe.

## Commands

- `npm install` — plain, no flags. `--legacy-peer-deps` was once required because
  `@types/react` sat at `^19` while `react` was `18.3.1`. Both are on `^19` since
  the React 19 upgrade (2026-08-16), so they match and there is no peer conflict.
  Don't reintroduce the flag — it hides exactly the conflicts an upgrade needs to
  surface.
- `npm run dev` — web preview at `localhost:5173`.
- `npm test` / `npm run test:watch` — Vitest.
- `npm run benchmark` — reads `history.json` and prints the docs/manual-testing.md
  §10.5 provider table (speed *and* word-error-rate), grouped by provider pair.
  **`--since <date>` is not optional once the app has changed what it sends**
  (added 8 Sep 2026). **A row is keyed on `polishModel`, and for a cloud run that field
  holds the *provider* id, not the model id** — `useDictationPipeline.ts:588` sets
  `engineDetail` to `polishProviderId` for `cloud` and to the model only for `ollama`. So
  `openai → cloud:openai` and `openai → cloud:groq` separate on their own, and two
  *OpenAI* models collapse into one row. Comparing models inside one provider needs one
  line changed (write the model id) — do not assume the fix is needed for a cross-provider
  comparison, which was the wrong call made on 11 Sep 2026 and corrected the same day.
  A pair is not a fixed thing: the pre- and
  post-`reasoning_effort` OpenAI runs key to the same `openai → cloud:openai`
  row, and their blended median reported **5.6s** — a number describing no
  version of this app that ever existed, with the run that proved the fix being
  the one averaged away. An entry with no timestamp is left out when a cutoff is
  given, on purpose: it cannot be shown to be after it.
  Read-only. Benchmark runs are detected automatically: §10.5's script is fixed,
  so `benchmark.ts` recognises it and scores the raw transcript against it —
  there is no mode to switch on, and deliberately no UI for it.
- `npm run typecheck` — `tsc --noEmit`. **Run it alongside the tests.** Neither
  `vite build` nor Vitest checks types — both hand the files to esbuild, which
  strips annotations without reading them — so a green test run says nothing
  about the types. The project had no `tsconfig.json` at all until 2026-08-13,
  which meant `tsc --noEmit` silently checked nothing and reported success.
- `npm run electron:dev` — desktop app straight from source.
- `npm run electron:pack` — fast unsigned `.app` in `release/mac-arm64/`.
- `npm run install:app` — packs, then replaces `/Applications/Voice Flow.app`
  and deletes the build output. The normal way to update your own copy;
  only an installed copy registers as a login item.
- `npm run uninstall:app` — full removal: bundle, prefs, caches, login item, TCC
  grants and the LaunchServices registration. Keeps user data unless `--purge`.
  `--dry-run` prints the plan.
- `npm run reset:permissions` — the TCC + LaunchServices half of the above with
  no deletion of the app or data. This is the fix for duplicate Privacy rows.
- `npm run doctor:paste` — asks macOS the paste path's own focus question about
  every running app and prints the verdict per app. Read-only. **Run it after
  touching `focusTarget.js`, and after a macOS update.** It exists because
  nothing in `npm test` can see this class of bug: `clipboard.test.js` replaces
  `focusTarget.js` wholesale and `focusTarget.test.js` feeds the parser canned
  osascript output, so a probe that was simply *wrong about macOS* passed 964
  tests while blocking every paste into Slack, VS Code and Claude Desktop. The
  suite proves the code does what it says; this proves macOS agrees. The script
  asserts its copy of the query still matches `focusedElementState()` and exits
  2 if they have drifted, so it cannot report health for a script the app no
  longer runs.
- `npm run doctor:polish` — replays the raw/polished pairs already in `history.json`
  through `structureCues.ts` and `polishGuard.ts` and prints what the guard would have
  said about dictations that have already happened. Read-only, no model, instant, and
  **exits 0 whatever it finds** — past violations are the measurement, not a failure of
  the run. `--since <date>`, `--verbose`, `--plans`. Same argument as `doctor:paste`:
  the suite proves the guard is self-consistent, this proves it agrees with a real
  history. It is also where a threshold gets chosen rather than guessed, and it has
  already earned that twice — it demoted `dropped-content` to a warning, and it found
  two bugs in the guard itself (a false duplicate whenever whisper returned one
  unpunctuated blob, and a stemmer reading "getting" as `gett` so it did not match
  "get"). **It runs stage 2 on the raw before comparing**, because the guard's contract
  is that it sees what the *model* saw; it cannot run stage 1, since
  `dictionaryCorrect.ts` imports `voiceflowSettings`, so a proper noun the Dictionary
  would have repaired still reads as the model changing a word.
- **`npm run doctor:polish -- --rerun --model <a,b,c>` is the other half of that
  command, and it produces new polishes rather than reading old ones** (added 9 Sep
  2026). It sends the stored raws through the real prompt and the real guard against
  named **Ollama** models and reports, per model, the shape that came back and the share
  of the speaker's words that survived. `--limit n` caps the run; `--runs n` asks the
  same input repeatedly, which is how the phase's own question — the same dictation
  twice, same shape? — gets asked. Nothing is written: no history entry, no setting, no
  audio. Four things about it not to undo. **One prompt for every model** —
  `auto-detect`, no agent, no custom writing rules, AI Processing at its defaults —
  because this is a comparison between models and an active agent suppresses the
  structure rule entirely (`structureLicensedByChoice`), which would leave the run
  printing a shape table that measures nothing. **Ollama only**, because
  `electron/ollama.js` is the client the app uses while `llmProvider.ts` reads settings
  and cannot be imported here — the cloud half of a model question belongs to
  `npm run benchmark`. **A run the model cut short is named and not scored**, since
  `completedPolish` would refuse it outright. And **the report reads
  `structureCounts`/`contentWordDelta` out of `polishGuard.ts`** rather than counting
  bullets and lost words itself: a ruler that disagrees with the thing it measures is
  worse than no ruler, and `polishGuard.test.ts` pins that the words-kept number is
  built from the same two numbers `dropped-content` puts in its own message. Note the
  kept column is **set membership**, so a halved word count beside 100% kept means
  repetition went, not content.
- `npm run doctor:vault` — the wiki health check, read-only. Twelve mechanical
  checks over the Obsidian vault; exits 1 on a problem, 0 otherwise. The same
  report is behind **Check my wiki** in Settings → Vault. **A link to a page with
  no file is two findings, not one, and what separates them is the declaration
  rather than the missing file** (split 8 Sep 2026). `[[mod-hero]]` is named in
  `app-hero-driver-hd-od`'s `modules:`, so the taxonomy says that page exists and
  is awaiting its first source — `declared-not-written`, a **note**, the same
  class as `empty-page`. A link nothing declares is a typo or a deleted page, so
  it stays `broken-link` and stays a **problem**. While both were red this exited
  1 on a vault with nothing wrong with it, which is an exit code that cannot gate
  anything and a report that has to be explained away every run. Do not merge them
  back. Findings are also deduped per missing page — that one page links
  `[[mod-hd]]` twice.
- `npm run compile:vault` — compile every source in `raw/` no page cites yet.
  **Preview by default**; `--apply` writes. `--only <substring>`, `--model <name>`
  and `VAULT_ROOT=…` all work. The same flow is behind **Compile** in Settings →
  Vault. The vault is a git repo as of 21 Aug 2026, and **the undo depends on whether
  the change is committed**: straight after an apply nothing is staged, so it is
  `git checkout -- .`; `git revert` is for a compile you already committed. Getting
  this the wrong way round is a no-op that reads as a failed undo.
- `npm run electron:build` — full `.dmg` in `release/`.

## Known pitfalls

- **Small local models need `format: 'json'`, not a prompt asking for JSON.**
  `ollama.js` passes Ollama's `format` through since 21 Aug 2026 — that is
  grammar-constrained decoding, where the sampler refuses a token that would break
  the JSON, as opposed to a request the model can fumble. `qwen3.5:9b` returned an
  unterminated array on its second call without it. Optional and unset for every
  other caller, so the dictation path is unaffected. Two more things a live model
  taught that no fixture would: a destination list written as `demo / shop / cart`
  is ambiguous enough that the model replied with project `"shop"` (it is now
  listed as the JSON object it must produce), and lists come back as **arrays**
  however the prompt asks — `String(['a','b'])` is `'a,b'`, which produced a whole
  section rendered as one comma-joined line.
- **The vault's own schema disagrees with the vault in one place.**
  `schema/CLAUDE.md`'s tree diagram puts the project page *beside* its folder;
  the vault keeps it *inside* (`wiki/Work/project-v-thru/project-v-thru.md`).
  The vault wins — that is what `pathForPage` follows. No difference to a
  `[[wikilink]]`, every difference to creating a new project.
- Signing is done by `scripts/install-app.js` after `ditto`, not by
  electron-builder (`identity: null`, it does **not** sign). Not notarized, so
  first launch needs right-click → Open and `spctl` reports "rejected" — that is
  expected and unrelated to permissions.
- What governs macOS permission grants is the **designated requirement**, and
  ad-hoc signing gets it wrong: no certificate chain means the requirement is a
  bare `cdhash`, which changes every build, so each rebuild is a new app to TCC.
  Symptoms are misleading — System Settings shows the old row still enabled, the
  app reports the permission missing, and duplicate rows pile up. A dropped
  Microphone grant reads as "the floating widget is dead" because
  `handleIdleClick` opens the main window instead of recording. Fixed by
  `npm run signing:cert` (self-signed cert in the login keychain), which makes
  the requirement `identifier "com.voiceflow.desktop" and certificate root = …`.
  Verify with `codesign -d -r-` — `install-app.js` now asserts this itself and
  warns when the requirement comes out hash-pinned, because signing can succeed
  and still produce a bare cdhash.
- Duplicate Privacy rows are not only a cdhash story. `lsregister -dump` found
  **four** bundles claiming `com.voiceflow.desktop`, shipped under three product
  names from three different project directories plus a `.dmg` volume.
  LaunchServices registrations outlive the bundles they point at,
  so a build directory deleted months ago still contributes a row, and `tccutil
  reset` alone does not remove it — the registration has to go too. Note
  `lsregister -kill -r` no longer exists (current macOS answers it with "the -kill
  option has been removed because it was dangerous and no longer useful", exit 1);
  use `lsregister -u <path>`, which works even when the path is already gone, then
  `-gc`. Both halves are `npm run reset:permissions`. Verified clean 17 Aug 2026:
  one bundle claims the appId (`/Applications/Voice Flow.app`, and it exists), so
  `claimantsToUnregister()` returns `[]`. This corrects an earlier note here that
  said the old repo at `~/Documents/VS Code/Voice Flow_v1` still builds this same
  appId and would re-create the collision — it doesn't, it is
  `com.voiceflow.v1.desktop` / productName `Voice Flow_v1`, a separate app to
  macOS. A *new* directory building `com.voiceflow.desktop` would still collide,
  which is why `install-app.js` reports any foreign claimant it finds rather than
  editing the other repo.
- **Stale LaunchServices rows are not only about bundles that claim the appId —
  Electron helpers claim ids that *extend* it, and nothing enumerated them until
  19 Aug 2026.** `parseBundleClaimants()` matches `identifier === APP_BUNDLE_ID`
  exactly, on purpose: helpers are children of a bundle already listed, so counting
  them would multiply the reported number of competing installs. But that also meant
  no code path could ever unregister a *dead* helper, and five had piled up here —
  four from an unmounted `.dmg` volume and one whose parent bundle had been deleted
  months earlier. `reset:permissions` reported "1 bundle registered, no stale
  registrations" while all five sat in the database. Fixed with a second parser,
  `parseHelperClaimants()` (strict descendant, so `com.voiceflow.desktoptools` is not
  caught), surfaced through `launchServicesRegistrations()` in `macActions.js`, which
  reads the dump **once** — it is tens of megabytes and takes seconds. `uninstall`
  clears helpers too, or a reinstall inherits their rows. `claimantsToUnregister`'s
  `keepPath` now protects the whole **subtree**, since a live app's helpers live
  inside its bundle. One thing this still cannot see: a bundle on an **unmounted
  volume** has no `identifier` in the dump at all (macOS cannot read its Info.plist),
  so it is invisible to both parsers. One such entry existed here (a `.dmg` volume
  from `electron:build`) and was cleared by hand on 19 Aug 2026; the dump now holds
  just the installed app and its live helper. Teaching the parser to catch the class
  was declined on evidence, not overlooked — Privacy shows **one** Voice Flow row for
  Microphone and one for Accessibility, so there was no stale row to reclaim. See
  `docs/archive/backlog-old.md` §0.2 before reopening it.
- **Both migrations are gone (19 Aug 2026), and `preload.cjs` no longer touches
  `localStorage`.** The second one was `migrateCategory()` in `preload.cjs`, which copied
  the old browser `localStorage` keys into the eight category files on first launch after
  the app moved to file-backed storage. All eight files exist and hold real data here, so it
  had been skipping every branch for months; 76 lines went, plus `writeCategorySync()`,
  `readLocalStorage()` and `readLocalStorageJSON()`, which nothing else used. **The startup
  loop now sets a missing category to `null` and writes nothing** — that is not a
  regression: `readCategory(category, fallback)` in `src/app/lib/dataStore.ts` maps `null`
  to the caller's fallback, and `snippets`/`styles` already relied on exactly that (the old
  migration returned `null` for both deliberately so their defaults would seed). A fresh
  install is identical, minus the empty JSON files it used to write on launch. Full record in
  `docs/archive/backlog-old.md` §0.3. Note this is a *different* migration from the pre-rename one below
  and had none of its danger — it was dead, not a trap.
- **The security table in `docs/roadmap.md`'s security table named a control that did not exist**, corrected
  19 Aug 2026. It claimed a *"regex scrub for API keys / bearer tokens / card numbers before
  any cloud call"*; there has never been such code. The row now reads **"Gap today"** and the
  work sits at Phase 4 item 2b next to the `safeStorage` migration. Do not restore the old
  wording without the code. Worth knowing why it is a *low* gap: snippets expand at stage 5
  (after the cloud call) and vault chat never leaves the Mac, so the only exposed path is
  speech — and speech-to-text does not reproduce `sk-…`/`AIza…` intact. And why the fix is
  not free: a scrub that silently eats a spoken order number costs real text every day.
- **The pre-rename migration code is gone (19 Aug 2026), and `productName` is now
  the only place the app's name lives.** The app briefly shipped under a different
  product name; macOS derives an Electron app's data folder from `productName`, so
  renaming it back pointed the app at an empty folder, and
  `electron/renameMigration.js` copied the old one across on first launch. That
  file, the startup block in `main.js`, `LEGACY_APP_NAME`/`migrationLooksComplete()`
  in `appFootprint.js` and the legacy branches in the three scripts have all been
  deleted — the pre-rename folder and bundle no longer exist on this machine, so it
  was rescuing nothing. 18 tests went with it (1011 → 993). Full record in
  `docs/archive/backlog-old.md` §0.1. **If a second product name is ever needed again, add a new
  constant — never make it equal to `APP_NAME`.** The old code guarded this and the
  guard is gone: two equal names make `legacyDataDir === currentDataDir`, so a
  migration-complete check compares the live data folder against itself, returns
  true, and a plain `npm run uninstall:app` deletes user data while printing "Kept
  your data at …".
- `systemPreferences.isTrustedAccessibilityClient()` can return **true** while the
  real AX calls are still denied (a stale grant row from an earlier build). The
  guard at the top of `pasteText` then passes, and the failure surfaces two steps
  later as `hasFocusedElement()` returning a definite `"none"` — so the user is
  told "No text field was focused" for what is actually a permissions problem.
  Suspect this whenever that message appears over an app with a field plainly
  focused.
- System Events cannot coerce an AX element reference into a variable for many
  apps: `set x to value of attribute "AXFocusedUIElement" of proc` errors on
  Slack, VS Code and Claude Desktop even with a text field plainly focused. In
  `focusTarget.js` that turned every paste into an Electron app into "No text
  field was focused". Use `exists value of attribute …` (a boolean, no
  coercion), look the process up by `unix id` rather than `whose frontmost is
  true` (which can name Voice Flow's own widget panel), and treat only a
  definite negative as "nowhere to paste". `clipboard.test.js` mocks
  `hasFocusedElement` wholesale, so the suite cannot see a broken script —
  the AppleScript itself is pinned in `focusTarget.test.js`.
- **A missing `AXFocusedUIElement` is not an empty app — it is Chromium.** Fixed
  18 Aug 2026. `focusedElementState()` asked System Events whether the target app
  has a focused element and read "no" as `FOCUS_NONE`, which `clipboard.js` treats
  as a hard stop. But Chromium keeps its accessibility tree switched off unless a
  screen reader is running, so **Slack, VS Code, Cursor, Windsurf, Claude Desktop
  and Brave all answer "no focused element" while a text field is plainly focused
  and frontmost** — verified by running the probe against each of them. The
  attribute is *listed* on the process; it simply never has a value. Auto-paste
  was therefore dead in most of the apps this product exists to type into, and
  the user saw "No text field was focused" every time. The window count now
  carries the whole "nowhere to paste" verdict (the Desktop is Finder with zero
  windows, and an app with no windows has nowhere to put a keystroke either); a
  missing focused element is `FOCUS_UNKNOWN`, which pastes and keeps the
  transcript on the clipboard. `clipboard.js` needed no change — its four-state
  handling was already right, the verdict feeding it was wrong. Note this is the
  *third* fix in this area and the first with a real-OS check behind it; see
  `npm run doctor:paste`.
- **The floating capsule follows the cursor's display, and that is deliberate — not
  a bug in position persistence.** Added 19 Aug 2026 (`followCursorPosition` in
  `widgetPlacement.js`, `followCursorDisplay`/`syncCursorPoll` in `main.js`). The
  hotkey is global, so dictation gets started from an app on any screen, while the
  capsule stayed wherever it was parked — on a two-monitor desk that means
  recording with the level meter, the ✕ and the transcript card on a panel the
  user isn't looking at. macOS emits no cursor-changed-display event, so a 400ms
  `getCursorScreenPoint` poll does it, armed only while 2+ displays are attached.
  Three things to know before touching it. A crossing calls
  `defaultWidgetPosition` rather than carrying the dragged offset across, so
  **crossing screens discards a dragged position** — that is the chosen trade
  (bottom-centre is the one spot that is always findable on a display of unknown
  size), not a regression, and it is inert on a single display so a dragged
  capsule there is never snapped back. Which display the capsule is *on* is read
  from the **bottom-centre of its canvas**, never by most overlap: the canvas is
  420x260 of transparency around a 40x8 control at its bottom edge, so overlap
  names a display the user sees nothing on. And the poll returns early while
  `widgetDragOrigin` is set, or a drag across a display boundary fights it for the
  window's position. There is deliberately **no setting** for this.
- **History's entry cap is 5000, and uncapped is the stated goal.** Raised from
  50 on 18 Aug 2026 (`USER_HISTORY_LIMIT`). The 50 came in with the initial
  commit as a scaffold default and silently contradicted the retention control,
  which offers "Forever" and defaults to it — Settings promised permanent history
  while the store kept 50, so the retention hint in `SettingsGeneral.tsx` now
  interpolates `getHistoryLimit()` and cannot drift from the code again. Two
  things this changed that a bigger number would otherwise have broken:
  `addHistoryEntry` built its id with `Math.max(Date.now(), ...entries.map(…))`,
  and spreading an unbounded array into an argument list throws `RangeError` in
  the tens of thousands — it reduces now; and `History.tsx` rendered every row
  with a `delay: i * 0.05` stagger, so the 5000th card would have waited over
  four minutes to appear — it paginates instead, with a capped stagger.
  Pagination is Previous/Next over a `page` window (10/20/50 rows, chosen on
  the page itself and persisted by `getHistoryPageSize`), not the incremental
  "Show more" it started as, since that only ever grew the mounted-card count.
  The rendered page is `Math.min(page, pageCount)` rather than `page` alone:
  the widget writes entries from another renderer while this page is open, so
  the page the user is on can stop existing mid-session.
  **Genuinely uncapped is deferred, not rejected**: it needs the privacy question
  answered (every transcript ever dictated, on disk in plain JSON, forever) and
  the startup read made lazy, since `preload.cjs` parses `history.json`
  synchronously before the renderer starts — around 1.1KB an entry, so ~11MB and
  ~100ms at 10,000. Do not "solve" a slow History page by lowering the cap.
- **Cloud transcription now writes code forms itself, and that starves every
  spoken-cue rule in `vibeCodeProcessor.ts`.** Fixed 18 Aug 2026. The rules were
  all written for what a person *says* — "index dot t s x", "constant max
  retries", "call handle submit" — but OpenAI transcription returns
  `index.tsx`, `maxRetry` and `call handleSubmit` already joined. Two separate
  failures came out of that. **It broke text:** the camelCase rule matched
  `(cue)(word)(word)` case-insensitively, so with the identifier already joined
  the third group was the next *English* word — "a function called handleSubmit
  that checks" became `handleSubmitThat`, eating "that". The polish model then
  repaired the grammar it had been handed by putting "that" back, and stage 4
  ran the same rule a second time on the restored text, producing
  `handleSubmitThatThat`. `retryCountSo` is the same bug; `retryCount, so`
  survived only because the model happened to write a comma, which blocks the
  regex — which is why it looked intermittent. **And it silently did nothing:**
  `@index.tsx`, `const MAX_RETRIES` and `handleSubmit()` could never be produced,
  because the cue they match on never arrived. Three fixes, all needed:
  `isAlreadyIdentifier()` refuses to consume a word carrying an internal capital
  (position 0 is sentence case and still transforms); each rule gained a branch
  for the already-joined form, including the mixed "source slash comments slash
  button.tsx" that real transcripts contain; and `applyPostLlmStages` takes
  `spokenTransformsApplied` so stage 4 no longer re-runs what
  `protectVibeCodeTokens` already ran. **The suite could not see any of it** —
  every test fed stage 4 the *spoken* form, which is not what stage 4 receives in
  the app. `textPipeline.test.ts` now has a `round trip` block that goes
  protect → polish → restore → stage 4 with verbatim transcripts from
  `history.json`. Same lesson as `doctor:paste`: pin the real input, not the
  convenient one.
- **`electron/` and `scripts/` are 29% of this codebase and `tsc` has never read a line
  of either.** `tsconfig.json` is `include: ["src"]`, so 6,035 lines of main process and
  2,679 lines of CLI tooling are unchecked — and that unchecked share holds the vault
  write path and the paste path, the two areas this file documents as needing certainty.
  **Measured 9 Sep 2026 with `checkJs`: 52 real errors at `strict: false`**, 671 with
  strict on, where the difference is unlabelled variables rather than mistakes. The 52
  are roughly eight root causes — one missing `tag` field in `macActions.js`'s JSDoc
  accounts for 14 of them — and one is a genuine bug the compiler found on its first
  run: `main.js` passes **`fullScreenable`** to the widget window, where Electron's
  option is `fullscreenable`, so a constraint sitting in a block of four real ones has
  never applied. Scheduled as Phase 2.75 item 7. Related: `allowImportingTsExtensions`
  in `tsconfig.json` exists **because** of this split — `scripts/` is JavaScript, so it
  cannot import a `.ts` module the way `src/` does, and the flag is what lets
  `doctor-polish.js` run the guard the app runs instead of a fourth
  must-agree-by-hand copy. Close the split and the flag stops being needed.
- **A polish the provider cut off is refused, and so is an empty one** (added
  8 Sep 2026, `completedPolish` in `llmProvider.ts`). A Test 23 run returned
  **31 words of a 165-word dictation and the app displayed them**: Gemini had
  stopped at `maxOutputTokens` mid-clause and nothing read `finishReason`, so a
  cut-off answer was indistinguishable from a finished one. 134 words gone, no
  error — worse than the 400 it replaced, which at least fell back and kept
  them. All three cloud providers spell the reason differently
  (`finish_reason: 'length'`, `stop_reason: 'max_tokens'`,
  `finishReason: 'MAX_TOKENS'`), hence one lower-cased set. Three things not to
  undo: **throwing is the feature** — `useDictationPipeline` catches a polish
  failure and runs `applyFallbackCleanup`, so a truncation costs the style pass
  and never the words; **a provider reporting no reason is trusted**, because
  refusing what nobody said was cut would fail ordinary dictations; and **the
  empty check covers the local and Ollama providers too**, which send no output
  cap but can still return nothing, and nothing replacing a whole transcript is
  the same defect at the other end.

  **The truncation half did *not* cover those two until 9 Sep 2026, which is the
  half that mattered offline.** `completedPolish` reads a reason and only the three
  cloud providers passed one: `electron/localLlm.js` returned `content` alone and
  `electron/ollama.js` returned `json.message?.content ?? ''`. Ollama does report
  it — a capped request answers `done_reason: "length"`, verified against the
  running server — so the fix a silent truncation earned was missing from exactly
  the engines a private dictation uses. Both IPC calls now return
  `{ content, finishReason }` rather than a bare string, and the shape is the
  point: a string cannot carry the reason, and a caller that cannot see the reason
  cannot refuse a fragment. Ollama's `done_reason` and llama-server's
  `finish_reason` are renamed to **one** field in the main process so the renderer
  reads one thing whichever engine answered; `length` is the value both use, so
  `TRUNCATION_REASONS` needed no new case. `vaultDecide.js` reads `.content` and
  ignores the reason on purpose — a cut-off answer there is malformed JSON, which
  `parseObject` already refuses by name. Still open: `chatOllama` streams and has
  the field on its final frame, so a truncated **Chat or Vault** answer is
  displayed as a whole one.

  Its Gemini-specific companion: **`maxOutputTokens` is now the ceiling on every
  Gemini request, unconditionally** (10 Sep 2026). Gemini bills thinking against
  that budget, and it used to be sized to the *visible* answer whenever the
  thinking budget had not been refused — 895 chars asks for 1024, the floor. That
  branch rested on a budget of 0 meaning nothing to pay for. **A thinking budget
  is a target, not a cap:** asked for the floor budget on the §10.5 transcript,
  `gemini-3.6-flash` still spent ~950 tokens, which left 74 for the answer and
  truncated the polish at 89 words of 168 and then 35 — the exact defect
  `completedPolish` exists to catch, produced by the branch meant to prevent it.
  The ceiling is the right number rather than a guess at how much a model will
  think: polish output is bounded by the transcript anyway, so asking for more
  costs nothing when it is not used.

- **A dictionary pair does not license guessing, and every canonical used to be
  a fuzzy target** (fixed 8 Sep 2026, `dictionaryCorrect.ts`). The module has
  always documented two modes — an explicit `spoken => Canonical` pair means
  *"rewrite this exact phrase, no guessing"*, a plain entry opts into near-miss
  repair — but `applyDictionaryCorrections` built its fuzzy list from
  `dictionary.map(e => e.canonical)`, pairs included. So `grok => Groq`, written
  the careful way, put "Groq" one edit from any four-letter g-word and the
  ordinary word **"grow" came back as "Groq"**. A user cannot avoid that by
  being precise, which is what made it a bug rather than a footnote. Fuzzy edits
  are now opt-in per entry; **case-only repair stays on for every entry**,
  including a pair's canonical, because it cannot change *which* word was said —
  only how it is spelled — and it is the commonest real correction
  (`clickup` → `ClickUp`).

- **`whisper-server` decodes with `--beam-size 5`, not greedily** (added 8 Sep
  2026). The server defaults to `-1`, which commits to the highest token at
  every step with nothing to back out to — and that is where a repetition loop
  comes from. One Test 23 run came back as "of of of of of" and "speed speed
  speed speed" with whole clauses missing, **25% word errors against 8.9-11.9%
  for its neighbours on the same script and model**. It costs transcribe time,
  so `npm run benchmark --since <date>` is how to judge it, and reverting is one
  line. Deliberately *not* added: `--no-speech-thold` or `--vad`, which would
  suppress the stray "thank you" Whisper writes over trailing silence — both
  work by discarding audio judged silent, and losing words is the one thing this
  app must never do. A cosmetic artifact is the better trade, and
  `localWhisper.test.js` pins their absence.

- **Word errors are a transcription story, not a polish one** (measured 8 Sep
  2026). Both engines sit at 10-11% on the fixed script and make the *same*
  mistakes: `off` heard as "of" in every run, `finishes`/`waits`/`limits`/
  `costs`/`handles`/`accents` losing their endings, `steadier` → "sturdier",
  `Groq` → "grok"/"g lock"/"grog"/"glock". OpenAI adds its own — `new dictation`
  → "addiction", `tier` → "tire". So a bad transcript is **not** a reason to
  switch provider; local is the fastest pair *and* matches cloud on accuracy.
  Two things follow. Product names belong in the Dictionary, which already
  biases the STT model itself through `buildDictionaryPrompt` on **every** path
  including local (`transcription.ts:307` → `localWhisper.js` forwards `prompt`
  to `/inference`) — so "Whisper is not given the dictionary" is a wrong
  diagnosis worth not repeating. **That prompt is deduped as of 9 Sep 2026**, and
  the reason is the interaction between the two features: writing `grok => Groq`
  the careful way six times is six entries with one canonical, so the sentence
  read *"… Qwen, Groq, Groq, Groq, Groq, Groq, Groq, OpenAI, Gemini."* while the
  hard 900-character cap silently dropped real terms off the end. The entries stay
  as they are — the pairs are what make the correction side exact — and only the
  prompt dedupes. Exact match, not case-insensitive: two canonicals differing only
  in case are a contradiction in the user's own dictionary, and picking a winner
  would hide it. And `of`/`off` is **not** a polish bug: the
  sentence is grammatical either way, so a grammar pass has nothing to catch,
  and fixing it would mean guessing at the speaker's meaning.

- **The polish step restores standard written grammar, and that reverses an
  earlier rule** (decided 8 Sep 2026). `polishPrompt.ts` asks for articles,
  plurals, subject-verb agreement, tense consistency and prepositions. It used to
  say *"fix obvious grammar issues"* and, two rules later, forbid standardising
  *"article usage, tense choices, word order"* as a valid regional variety — so
  the prompt asked for both answers to one question, and which side won was the
  model's choice rather than the app's. What survives from the old rule is the
  half that was never about grammar: **vocabulary, idiom and register are the
  speaker's.** Correct the grammar around a regional word, never replace the
  word — "do the needful" and "kindly revert" are word choices, and a model that
  neutralises them into American English has rewritten the speaker. Two tests pin
  the pair, including a `not.toContain` on the old instruction, because either
  sentence alone passes while the prompt contradicts itself.

  **A second clause went on 9 Sep 2026, and the reasoning generalises: a vague
  duplicate is not free.** The regional rule used to end *"and never rephrase a
  clear sentence merely to make it sound more native"*, which asked the model to
  judge which sentences are "clear" — the same unbounded judgement that made the
  old one-line `auto-detect` unreliable — while the grammar rule above it already
  forbids swapping a word for a smarter one. So it decided nothing new, and
  competed for attention in a fourteen-rule prompt read by models as small as 3B.
  A test pins its absence *and* the protection that remains, because the point is
  that nothing was given up. If rephrasing ever needs forbidding harder,
  strengthen the grammar rule — that is where the decision lives.

  **Auto-punctuation gates the prompt as well as stage 2, since 9 Sep 2026.** It
  used to gate only `applySpokenPunctuation` while the rule telling the model to
  convert spoken punctuation was emitted unconditionally — so switching it off to
  get the literal word "period" written out still produced a full stop.
  `PROCESSING_RULES.autoPunctuation` now states the negative, like every other
  OFF rule.

- **A style or agent must never cap the output length.** `STYLE_RULES.casual`
  said "max 2-3 sentences", the seeded Casual profile said "Max 3 sentences", and
  the Slack Update agent said "at most three sentences" — each of which
  instructs the model to *drop the speaker's content*, directly contradicting the
  contract at the top of `polishPrompt.ts`. Removed 18 Aug 2026, with a test in
  `styleProfiles.test.ts` and `agentPresets.test.ts` asserting no built-in does
  it again. Related trap: `DEFAULT_STYLE_PROFILES` **overrides** the built-in
  instruction of the same id, so a seeded rule that omits something the built-in
  said is a silent regression — Formal's seed said "No abbreviations" and never
  mentioned contractions, so Formal kept saying "I'm" while the built-in rule
  forbidding it sat unused. A seed has to be at least as complete as the rule it
  replaces.
- **`AiProcessing` is the exception to the rule below, and conflating the two has already
  cost a wrong answer** (11 Sep 2026). `getAiProcessing()` returns
  `{ ...DEFAULT_AI_PROCESSING, ...readSettingsFile().aiProcessing }`
  (`voiceflowSettings.ts:321`), spreading the defaults *under* the stored object on **every
  read** — so a flag that has never been written takes the current default, and changing a
  default later does reach an existing install. The seeded-defaults gotcha is about the
  category **files**, written once on first read. Do not cite it when deciding a new
  `AiProcessing` flag's default: there is no one-way door there, which is what makes
  shipping `removeRepetition` as `false` and flipping it after measurement a real option
  rather than a permanent choice.
- **Seeded defaults only ever reach a fresh install.** `styles.json`,
  `snippets.json` and friends are written once, on first read, so improving
  `DEFAULT_STYLE_PROFILES` or `DEFAULT_SNIPPETS` changes nothing for an existing
  install — including this machine's. There is deliberately no migration: on
  18 Aug 2026 the three style rules and the `repro steps` body were updated in
  `~/Library/Application Support/Voice Flow/data/` by hand, replacing only
  strings still verbatim equal to the superseded default so a user edit could not
  be clobbered (`.pre-fix-*` backups alongside). Remember this before concluding
  a defaults change "did nothing".
- **Never pass `--no-timestamps` to `whisper-server`.** Fixed 18 Aug 2026. It
  silently loses words: whisper.cpp decodes in 30-second windows and reads the
  timestamp tokens to decide where the next window begins, so suppressing them
  makes it advance a flat 30s and never decode what straddled the seam. A 46s
  dictation came back missing ~25 words *from the middle* — no error, complete
  audio, and the polish model faithfully cleaned up a transcript that had already
  lost the content, which is why it read as a polish bug. Measured on one fixed
  WAV: with the flag 95 words and a lost clause, without it all 106. The flag only
  ever suppressed timestamps in the HTTP response, which this app does not read
  (`/inference` returns `{ text }` either way) — pure cost. Without it whisper
  emits one line per decoded segment, breaking mid-clause, so
  `collapseSegmentBreaks()` folds those into spaces; the user's own breaks are
  still the words "new line"/"new paragraph" at that point and are inserted later
  by `spokenPunctuation.ts`, so nothing the speaker asked for is eaten.
  `localWhisper.test.js` pins both halves.
- **A GUI app does not inherit your shell's `PATH`.** Launched from the Dock or
  Spotlight the app gets launchd's environment, which here has no
  `/opt/homebrew/bin` (`launchctl getenv PATH` is empty). Homebrew writes
  `/etc/paths.d/homebrew`, but that is read by `path_helper` when a *shell*
  starts, never by launchd. So `brew install whisper-cpp` succeeds, `which
  whisper-server` works in Terminal, and the packaged app still reports the
  binary missing — which reads as a failed install and is not one.
  `electron/binaryPath.js` (`resolveBinary`) searches `PATH` first, then
  `/opt/homebrew/bin`, `/usr/local/bin`, `/opt/local/bin`. Both `localWhisper.js`
  and `localLlm.js` go through it; a new spawned helper binary must too.
- Anything the main process loads from disk at runtime must be in the
  electron-builder `files` array. `build/icon.png` (the tray icon) was not, so
  the packaged app had an invisible menu-bar icon while `electron:dev` — which
  runs from source — looked fine. `build/` is electron-builder's `buildResources`
  directory and is excluded unless listed explicitly.
- Debugging a launch from VS Code's terminal: `ELECTRON_RUN_AS_NODE=1` is set in
  the extension host, so the app binary runs as plain Node and exits 0 instantly
  with no window and no error. Use `env -u ELECTRON_RUN_AS_NODE`. See docs/manual-testing.md.
  This catches **`open -a` too**, which is the surprising part — `open` hands the
  calling environment to LaunchServices, so `open -a "Voice Flow"` from this
  terminal also exits 0 and starts nothing. `env -u ELECTRON_RUN_AS_NODE open -a …`
  is the form that actually launches the app.
- Sentence punctuation is added by the **transcription** stage on the Gemini path
  (`transcriptionPrompt.ts`), not only by polish. A polish-side rule cannot undo a
  split that Gemini already made, so rules about sentence boundaries belong in
  both prompts.
- The `pnpm.overrides` Vite pin is **gone** (removed with the Vite 8 bump,
  2026-08-16). It pinned `6.3.5` while the documented `npm install` flow read the
  `package.json` range instead, so it never applied — it just read as a real
  constraint. Don't reintroduce a package-manager-specific override here.
- `@types/react` 19 **removed the no-argument `useRef<T>()` overload**. Write
  `useRef<T | undefined>(undefined)`, not `useRef<T>()` — the latter is now
  TS2554, and it cascades into TS2322 wherever a cleanup path assigns `undefined`
  back. This bit `useDictationPipeline.ts` during the React 19 upgrade.
- Vite 8 warns on `__dirname` in config files (its future native config loader
  won't support it). `vite.config.ts` and `vitest.config.ts` use
  `import.meta.dirname`; keep it that way.
- API keys, transcription/polish provider choice, and Auto-punctuation live
  in **Settings → Models & Keys**, not General — General was trimmed down in
  a refactor and this has already caused README/INSTALL to go stale once.
- **Every cloud transcription provider now has a model override, and Gemini's is a
  quality control rather than a version field** (added 2 Sep 2026). `gemini-3.6-flash`
  was a bare `const` in `transcription.ts` while Groq and OpenAI both had settings —
  so Gemini's transcription model could not be changed from the app at all. The reason
  it matters more here: Gemini has **no dedicated speech-to-text model**, it prompts a
  general model with audio, so that id decides how well it hears you. Three separate
  settings keys (`groqTranscriptionModel`, `openaiTranscriptionModel`,
  `geminiTranscriptionModel`) on purpose — one shared key would make an id typed for
  Gemini become the model OpenAI is asked for.

  **OpenAI's field carries a shortlist as of 9 Sep 2026, and the finding behind it is
  the Gemini one again: `gpt-4o-mini-transcribe` is the cheapest of the five models the
  account offers.** A default chosen on price with accuracy paying for it, on what is
  now the primary cloud provider. What was actually broken was discoverability — the
  hint read *"including one that isn't listed here"* while listing nothing, so trying
  the better model meant reading OpenAI's catalogue first.
  `OPENAI_TRANSCRIPTION_MODEL_OPTIONS` feeds a `datalist` the way `MODEL_OPTIONS` does
  for polish; `gpt-4o-transcribe-diarize` and `gpt-live-transcribe` are left out because
  a single-speaker whole-file recording wants neither. **It is not a whitelist** and a
  test pins that — gating the field would put a retirement back in the release cycle.

  **The `gpt-live-transcribe` half of that reasoning is scheduled to stop being true**
  (11 Sep 2026). It is correct only while the recording *is* whole-file: measured over 73
  real OpenAI dictations, the transcribe leg is 2.3s that begins only once the hotkey is
  released, and a realtime session moves it into the time the user is already speaking.
  That is Phase 2.9 in `docs/roadmap.md`, which also records the seven facts it was
  checked against — and which is **conditional on Phase 2.75 item 18**, a benchmark run
  that acts on the larger leg (3.0s polish against 2.3s transcribe) and may remove the
  need for the phase entirely. The project's own rule, from `archive/backlog-old.md` §3:
  *"wrong model for the job before it's a pipeline problem."* Two of them are worth knowing before touching this list: **`keywords`
  works on the whole-file endpoint but only with `gpt-transcribe`**, not with today's
  `gpt-4o-mini-transcribe` default, and **`stream=true` on that endpoint buys nothing
  here** — it streams the answer back from a file already uploaded, so the last word,
  which is the one polish waits for, arrives at the same moment. It stays out of the
  shortlist until the phase lands, because a realtime model in a field that posts whole
  files would simply fail.
  **The shipped default is deliberately unchanged**: moving it costs more per minute on
  every dictation, so it wants `npm run benchmark -- --since <date>` behind it, not a
  comment.
- **Gemini polish is `gemini-3.6-flash` with `thinkingBudget: 1`, and those two are one
  change** (2 Sep 2026; the value was `0` until 10 Sep 2026). The default was
  `gemini-3.5-flash-lite`, Google's cheapest tier, which is why Gemini polish measured
  1.5s — the fastest of all three providers, and bought with the smallest model they
  sell. Flash-Lite does not think by default and Flash does, so moving the default
  without a thinking budget would have traded a quality problem for a latency one. Do
  not remove either half alone. Reasoning earns little on polish — it rewrites a
  transcript, it does not solve anything — which is the same finding as `think: false`
  on Ollama.

  **`0` is the value not to send, and that is measured, not a preference** (10 Sep
  2026). Two of the three ids in `MODEL_OPTIONS` refuse a budget of 0 outright —
  `gemini-3.6-flash` and `gemini-3.5-flash-lite` both answer `400 INVALID_ARGUMENT`
  naming nothing — while **all three accept 1**. So the app was asking for the one
  value most of its own shortlist rejects, and its fallback then dropped the parameter
  and let the model think unbounded. Through this prompt on the §10.5 transcript:
  **14.0s and 2,307 thinking tokens with the parameter dropped, 6.9s and 948 with a
  budget of 1**, for the same 159-word answer, the same 100% of content words kept and
  a clean guard verdict on both. `-1` is AUTOMATIC (unbounded on purpose) and `0` reads
  like the obvious choice, so `llmProvider.test.ts` pins both of them out by name.

  **The rename `thinkingBudget` → `minThinkingBudget` is how the learned cache was
  invalidated**, and it was not optional: this machine's `settings.json` held a
  remembered refusal of `thinkingBudget` for `gemini-3.6-flash`, learned about the old
  value, which would have suppressed the new one and left the change inert on the one
  install that found the bug. `refusedParams` is built from names
  `isOptionalRequestParam` recognises, so a rename drops the stale entries on load.
  **Whenever what the app asks a provider for changes, the cache key for that
  parameter has to change with it.**

  **It is asked for rather than assumed** (8 Sep 2026): this note used to say no refusal
  fallback was needed, because a model with no thinking capability accepts the field
  rather than rejecting the request. A Test 23 run disproved it — `gemini-3.6-flash`
  answers `400 INVALID_ARGUMENT`, so **every** Gemini dictation lost its polish step to
  `applyFallbackCleanup`, and the suite stayed green because the field was pinned
  against a mock. Gemini goes through `sendDroppingRefusedParams` like the rest, with
  the wrinkle below — and the loop is now the last resort rather than the expected path.
- **A model shortlist rots, and two of OpenAI's three ids did not exist** (checked
  against the live catalogue 10 Sep 2026). `MODEL_OPTIONS.openai` offered
  `gpt-5.6-mini`, a hard `404 model_not_found`, and `gpt-5.6`, which answers but is
  absent from `/v1/models` — an unlisted alias. The family OpenAI actually serves is
  **luna / sol / terra**, and all three were verified to answer a polish request with
  both optional parameters accepted and zero reasoning tokens spent. This is the Groq
  entry's mistake repeated on the provider that matters: a list headed "known to work"
  offered two ids that fail every call, on the one cloud provider with a key saved here.
  **And there is nothing faster *below* the default, which is the thing not to go looking
  for again** (searched 11 Sep 2026). The 5.6 family prices at Luna $0.20/$1.20, Terra
  $2/$12 and Sol $4/$20 per million in/out: **`gpt-5.6-luna` is the nano tier**, so the two
  other shortlist entries are larger and slower, not smaller and faster. Measured over the
  **87** real `cloud → openai` dictations in `history.json` — median polish **3,187ms**,
  median 66 words — the leg decomposes at Luna's ~105 tok/s into ~0.84s of generation,
  ~1.7s of the model's own time-to-first-token and ~0.6s of connection. **So a faster
  polish means a faster provider, not a smaller model**, and the candidate is Groq:
  `openai/gpt-oss-20b` is already `DEFAULT_MODELS.groq`, benchmarks at ~935-1,000 tok/s
  with 0.73s TTFT, and has never been used here (`api-keys.json` has `groq` empty). That
  is Phase 2.75 item 18, and the bar is `doctor:polish --rerun`'s words-kept column rather
  than the clock — 20B is the size class where the 10 Sep Ollama study found models buying
  shape compliance with lost content.

  `gpt-6-astra` is deliberately **not** offered — it works, but it refuses
  `reasoning_effort: 'none'`, so the loop drops the parameter and it reasons unbounded,
  which is the Gemini trade on the hot path. A test pins the default being in its own
  shortlist, which is the property that would have caught this.
- **There is one learn-and-retry loop for refused parameters, not one per
  parameter** (generalised 2 Sep 2026 when `reasoning_effort` became the second;
  `thinkingBudget` is the third, 8 Sep 2026).
  `sendDroppingRefusedParams` in `llmProvider.ts` takes the list of optional
  parameters in play and drops whichever the provider 400s on, remembering each in
  `modelsRejectingParams` — a **map** of `endpoint:model` → refused parameter names,
  which replaced the flat `modelsRejectingTemperature` list. Four things about it.
  **It is a loop rather than a single retry, and that is a bug fix:** with two
  optional parameters a model can refuse *both*, and the old one-shot retry could
  only ever learn the first, so the second refusal surfaced as a failed polish step.
  **Only a parameter that was sent can be the one refused** — the candidate set is
  passed into `refusedOptionalParam` and shrinks each pass, which is what makes
  termination provable rather than hopeful. And **the persisted key was reshaped
  without a migration on purpose:** the cache is learned, never a preference, so
  losing it costs one round-trip and no user data — the old key is read *once* as a
  seed and never written, so no write path can corrupt it and it falls out of
  `settings.json` on the next save. `modelsRejectingThink` in `electron/ollama.js`
  stays separate, and that is deliberate: it is in the main process against a
  different API shape, and sharing would mean an IPC round-trip before every
  request.

  **What the loop cannot do is forget, and that has already cost something**
  (found 10 Sep 2026). A refusal is remembered forever, so the cache can only ever
  accumulate constraints — and two things make an entry go stale: the provider
  changes its mind, and *the app changes what else it sends*. On this machine
  `gpt-5.6-luna` was recorded as refusing `temperature`, learned 2026-08-16,
  before `reasoning_effort` existed. Measured now: `temperature: 0` **alone** is
  still a 400 (*"Only the default (1) value is supported"*), and `temperature: 0`
  **with** `reasoning_effort: 'none'` is a 200. The two parameters are not
  independent, and an entry learned before the second one existed had been
  costing the app its only determinism lever on its primary cloud model,
  silently, ever since. That entry was cleared by hand; **nothing in the code
  re-checks one**, and a general fix — expiry, or keying the cache on the
  candidate set that taught it — is a backlog item rather than something this
  note pretends is handled.

  And **one provider is allowed to guess, because its refusal names nothing.**
  Google's is a bare *"Request contains an invalid argument."* — no `param`, no field
  path, not even the word "thinking" — so `refusedOptionalParam` cannot match it and
  the polish step simply failed. `callGemini` therefore passes a `blindDrop`
  parameter, which the loop drops on a 400 it could not explain. Three things hold
  that in: it is **opt-in per provider**, since for OpenAI and Anthropic an
  unexplained 400 is a bad key or a retired model and a retry would bury the real
  error behind a second identical failure; it fires **once** per request, so
  termination is still provable; and a guessed drop is **remembered only if the retry
  succeeded**, because persisting an innocent parameter would cost that model the
  latency win for good, silently, on the strength of an error about something else.
  `PARAM_ALIASES` exists to keep this the fallback rather than the path — a message
  that says "thinking" is matched by name, at no extra round-trip.
- **`reasoning_effort: 'none'` goes on every OpenAI-compatible polish request**
  (added 2 Sep 2026), and it is the cloud half of `think: false`. Same finding:
  polish rewrites a transcript, it does not solve anything, so reasoning earns
  almost nothing and costs seconds in the dictation hot path — OpenAI's own
  guidance names `none` for *"latency-critical work… such as voice"*. **Measured
  8 Sep 2026: OpenAI polish went 7.6s → 3.4s, total 10.9s → 6.7s.** It had been
  recorded here as *suspected*, on the grounds that `gpt-5.6-luna` reports 845ms
  median latency alone and 7.6s did not add up any other way; the Test 23 re-run
  confirmed it. The 19 Aug reading that blamed the model id was wrong — this is
  not a property of which model you pick. Sent to Groq too, where support is
  per-model (gpt-oss takes `low`/`medium`/`high` and may refuse `none`) — no
  special case needed, because a refusal is exactly what the loop above learns.
  Anthropic and Gemini are deliberately excluded from this *parameter*: Anthropic
  controls reasoning with a `thinking` block that is already off on
  `claude-haiku-4-5`, and Gemini's half is the `minThinkingBudget` above — which,
  since 8 Sep 2026, goes through the same loop, and which asks for a budget of **1**
  rather than 0 since 10 Sep 2026 because 0 is the value most of the shortlist refuses.
- Provider model ids rot on the provider's schedule, and each failure looks
  different. Verified 2026-08-16: **Anthropic** removed sampling parameters, so
  `claude-opus-5`/`claude-sonnet-5` 400 on the `temperature: 0` this app sends —
  every cloud provider now goes through `sendDroppingRefusedParams`, which
  learns the refusal once and drops the parameter thereafter. **Google AI Studio**
  no longer issues `AIza` keys; new keys are `AQ.` auth keys and the old ones stop
  working September 2026 (`KEY_PREFIXES` accepts both). **OpenAI's** transcription
  default (`gpt-4o-mini-transcribe`) was the one model id here never checked against
  a live catalogue; it was checked on 8 Sep 2026 and it is **not retired — it is the
  cheapest of the five on offer**, which is a different finding and the one that
  matters. See the note below on the shortlist.
- `npm outdated` has two blind spots worth knowing: it reads only the `latest`
  dist-tag, so **electron-builder** (whose tag is stale, and now reports *older*
  than what is installed) and **react-router** never appear. Check
  `npm view <pkg> dist-tags` when a package looks suspiciously current.
- `tsconfig.json` sets `types`, which **disables automatic `@types/node` pickup**.
  vitest 3 supplied it by accident; vitest 4 made it an optional peer and seven
  errors appeared in untouched files. `@types/node` is now a direct devDependency
  pinned to `^22` and `"node"` is listed in `types`. **Do not take the 26.x that
  `npm outdated` offers** — it is the only genuinely-behind dependency in the
  project, and deliberately so. **The typecheck is clean, and zero is now the
  baseline** (8 Sep 2026 — it had been 114 since 2026-08-16, all in four test
  files). Record the number before any upgrade regardless: at zero a new error is
  the only error, which is the whole point of getting there. Two real defects were
  hiding in that noise, both in `FloatingWidget.test.tsx` and both tautologies —
  a test setting `state = 'transcribing'` when `RecordingState` has no such member,
  and one setting `micPermission = 'prompt-blocked'` when `MicPermission` has no
  such member. Both passed, because the mocked `WidgetDock` renders whatever string
  it is handed. **The fix for a stubbed interface is `Partial<T>` plus one cast at
  the handover**, not a bare `let` — 73 of the 114 came from two untyped `let`
  declarations whose `any` spread through every assertion below them.
- **There are two Node runtimes here, and they do not match.** System Node is
  22.23.2 (scripts, tests, tooling); **Electron 43.4.0 bundles Node 24.18.1**
  (the main process). Verify with
  `ELECTRON_RUN_AS_NODE=1 ./node_modules/electron/dist/Electron.app/Contents/MacOS/Electron -p "process.versions.node"`.
  This corrects an earlier note here that claimed Electron 43 bundles Node 22.
  One `@types/node` serves both, which is why it is pinned to the **lower** of
  the two — it cannot then offer an API the older runtime lacks. Note also that
  `tsconfig.json` is `include: ["src"]`, so `electron/` is **not typechecked**.
- The Account page's Change Photo/Password/2FA/Cancel Subscription controls are
  non-functional "Coming Soon" placeholders, not bugs. `Pricing.tsx` and
  `ExportData.tsx` used to be listed here too and are now deleted — the first
  was never mounted on a route, the second was routed at `/app/export-data`
  with nothing linking to it and generated a "project structure" JSON that had
  drifted into describing a different codebase.
- `Help.tsx` is no longer a placeholder: the stale copy was rewritten against
  what the app does, and the dead Quick Links (Video Tutorials / Documentation
  / Community) and "Still need help?" buttons were deleted rather than left
  pointing at `href="#"`. It is search + category filter + FAQs and nothing
  else, so anything wrong on that page is now a real bug.
- **History is read-only, and `Help.tsx` is the reason** (settled 20 Aug 2026).
  `TranscriptionDetail.tsx` had a full Edit → Save Changes flow writing `polished`
  back through `updateHistoryEntry`; Help said History "does not edit in place".
  Help won: History is a record of what was dictated, and the Raw/Polished
  comparison that page exists for is only evidence about the pipeline while
  Polished is what the pipeline produced. `updateHistoryEntry` still exists and is
  used only by `toggleHistoryStar` — that the store *can* change any field is not
  an invitation to put the editor back. **Worth knowing how it survived:** Help,
  the by-hand guide and Test 24 all agreed with each other, so the test compared
  two documents and passed while the app disagreed with both. Test 24 now says to
  check the app.
- The `react-router` advisory (GHSA-qwww-vcr4-c8h2, RSC-mode CSRF) is **no longer
  outstanding** — corrected 2026-08-16. It was described here as permanent with no
  patched 7.x; the advisory was revised on 7 Aug 2026 to name **7.18.2** as the
  patched 7.x, and that is what is installed, so `npm audit` no longer reports it.
  React 19 is therefore no longer on a security clock. What `npm audit` *does*
  report is **nanoid `<3.3.18`** via `vite → postcss`; plain `npm audit fix`
  clears it and touches only nanoid. **Still never run `npm audit fix --force`** —
  it has previously "fixed" router advisories by downgrading to
  `react-router@7.11.0`.
- `react-router` is on **8.3.0** since 2026-08-16. v8 moved the DOM-specific
  exports out of the root entry: `RouterProvider` imports from
  **`react-router/dom`**, everything else (`Link`, `Navigate`, `Outlet`,
  `MemoryRouter`, `createBrowserRouter`, the hooks) stays on `react-router`. If a
  new router import fails to resolve, check which entry point it belongs to
  before assuming the package is broken.
